"""Build this dependency-free static site; Python 3.8+ standard library only."""
from pathlib import Path
import shutil

root=Path(__file__).resolve().parent
out=root/'dist'
if out.exists():
    shutil.rmtree(out)
out.mkdir(exist_ok=True)
for name in ['index.html','styles.css','model.js','content.js','app.js','README.md',
             'EDUCATOR_GUIDE.md','TEST_REPORT.md','LICENSE','THIRD_PARTY_NOTICES.md']:
    shutil.copyfile(root/name,out/name)
if (root/'screenshots').is_dir():
    shutil.copytree(root/'screenshots',out/'screenshots',dirs_exist_ok=True)
if (root/'audio').is_dir():
    shutil.copytree(root/'audio',out/'audio',dirs_exist_ok=True)
if (root/'tests').is_dir():
    shutil.copytree(root/'tests',out/'tests',dirs_exist_ok=True)
print(out)
