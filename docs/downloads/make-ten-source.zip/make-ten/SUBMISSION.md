# Submission: Ten Little Seeds — Make Ten

Task: **TSK-B1MHHF16** · `0x2a5807fef94f387afdd23c9b9529e50c809fae97004c988ce96efda3c92aa73c`

## Public preview

**[https://receiptwork-ma0914.github.io/receipt-cleanup-sample/make-ten/](https://receiptwork-ma0914.github.io/receipt-cleanup-sample/make-ten/)**

Public HTTPS with no login. The live preview passed anonymous HTTP checks and an agent-operated zero-answer browser smoke test on 15 September 2026 UTC; exact evidence is included in the archive. The preview uses the reviewed app source; archived documentation adds the resulting deployment evidence.

## Attached source archive

`make-ten-source.zip` contains a complete editable `make-ten/` folder:

- Dependency-free HTML, CSS and JavaScript, plus standard-library build/package scripts.
- Four quantity prompts including zero and ten, five make-ten bonds, six original manipulable stories, and a fresh two-step final challenge.
- Two selectable levels of support, optional explicit play/stop narration with 17 bundled MP3 prompts, visible hints, keyboard-operated native controls, and memory-only progress/reset.
- `README.md` with exact serve/test/build commands; `EDUCATOR_GUIDE.md` with objectives, adaptations, references and an offline follow-up.
- `TEST_REPORT.md`, 17 passing automated tests, nine real-browser CSS-width measurement records, public HTTP/DOM evidence, contrast calculations and eight actual browser screenshots.
- MIT licence for original work, third-party notices and audio provenance/permissions.

Unzip, open `make-ten/README.md`, and run `python3 -m http.server 8000 --bind 127.0.0.1 --directory .` from that folder. No package installation is required. The generated `dist/` folder is omitted from the archive; `python3 build.py` recreates it from the included source.

## Review limitations

Original AI-assisted work; no client, child-study or measured-learning claims. Browser evidence comes from an agent-operated desktop Chromium environment at 360/768/1280 CSS widths, with a separate public smoke check. Physical touch devices, full screen-reader/keyboard traversal, auditory prompt quality and forced reduced-motion preference were not tested. All nine measured layouts had zero horizontal overflow, no buttons below 48 CSS pixels, and no active animations/transitions under the observed default preference. Progress is deliberately temporary and is not saved across refresh. See the test report for the exact checked and unchecked actions.
