"""Create a complete editable source archive; no hidden/environment files."""
from pathlib import Path
import zipfile

root=Path(__file__).resolve().parent
out=root.parent/'make-ten-source.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root)
        if p.is_file() and not any(x.startswith('.') or x in ('dist','__pycache__') for x in rel.parts):
            if p.suffix in ('.html','.css','.js','.cjs','.md','.py','.png','.jpg','.jpeg','.txt','.mp3','.json') or p.name=='LICENSE':
                z.write(p,Path('make-ten')/rel)
print(out)
